<?php
// Text
$_['text_title'] = 'maib';
$_['text_maib_error'] = 'Plata a eșuat! Vă rugăm să încercați din nou.';
$_['error_no_currency'] = 'În funcție de setările proiectului dvs., sunt acceptate doar următoarele valute: USD, EUR, MDL.';
$_['error_no_payment'] = 'Plata a eșuat! Vă rugăm să încercați din nou.';
$_['error_callback_url'] = 'Acest Callback URL funcționează și nu poate fi accesat direct!';
?>