<?php
// Text
$_['text_title'] = 'maib';
$_['text_maib_error'] = 'Payment failed! Please try again.';
$_['error_no_currency'] = 'Depending on your project settings, only the following currencies are supported: USD, EUR, MDL.';
$_['error_no_payment'] = 'Payment failed! Please try again.';
$_['error_callback_url'] = 'This Callback URL works and should not be called directly!';
?>